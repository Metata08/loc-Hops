import React from 'react';
import { MapPin, Stethoscope } from 'lucide-react';

export const KioskHeader: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-100 p-4 flex justify-between items-center z-10 relative shadow-sm">
      {/* Logo Area */}
      <div className="flex items-center gap-3">
        <div className="relative w-12 h-12 flex items-center justify-center">
            <Stethoscope size={42} className="text-teal-700 absolute" strokeWidth={1.5} />
            <MapPin size={20} className="text-red-500 absolute -mt-2 ml-2 fill-red-100" />
        </div>
        <div className="leading-tight">
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Loc-Hops</h1>
          <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">Hôpital du Sénégal</p>
        </div>
      </div>
      
      {/* Status Indicators */}
      <div className="flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div>
        <span className="text-xs text-slate-400 font-medium">Système en ligne</span>
      </div>
    </header>
  );
};