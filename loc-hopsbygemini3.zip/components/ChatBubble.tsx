import React from 'react';
import { Bot, User } from 'lucide-react';

interface ChatBubbleProps {
  role: 'user' | 'model';
  text: string;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ role, text }) => {
  const isModel = role === 'model';
  
  return (
    <div className={`flex w-full ${isModel ? 'justify-start' : 'justify-end'} mb-4 animate-in fade-in slide-in-from-bottom-4 duration-500`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] gap-4 ${isModel ? 'flex-row' : 'flex-row-reverse'}`}>
        
        {/* Avatar */}
        <div className={`
          flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center shadow-sm
          ${isModel ? 'bg-teal-600 text-white' : 'bg-slate-700 text-white'}
        `}>
          {isModel ? <Bot size={24} /> : <User size={24} />}
        </div>

        {/* Message */}
        <div className={`
          p-6 rounded-3xl text-xl leading-relaxed shadow-sm
          ${isModel 
            ? 'bg-white text-slate-800 rounded-tl-none border border-slate-200' 
            : 'bg-teal-600 text-white rounded-tr-none shadow-md'}
        `}>
          {text}
        </div>
      </div>
    </div>
  );
};