import { GoogleGenAI } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

let aiClient: GoogleGenAI | null = null;

const getAiClient = () => {
  if (!aiClient) {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API Key is missing");
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
};

export const generateHospitalResponse = async (userPrompt: string, language: 'fr' | 'wo' | 'ar'): Promise<string> => {
  try {
    const ai = getAiClient();
    
    // Add language instruction to the prompt
    let langInstruction = "";
    switch (language) {
        case 'wo': langInstruction = "Réponds en Wolof si possible, ou en Français simple."; break;
        case 'ar': langInstruction = "Réponds en Arabe."; break;
        default: langInstruction = "Réponds en Français."; break;
    }

    const fullPrompt = `${langInstruction} Question utilisateur: "${userPrompt}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: fullPrompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1,
        maxOutputTokens: 150,
      },
    });

    const text = response.text;
    
    if (!text) {
      return "Désolé, je n'ai pas compris. / Bal ma, déggouma.";
    }

    return text;

  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Service indisponible. / Service bi dafa panne.";
  }
};