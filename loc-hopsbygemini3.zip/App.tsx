import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Globe, MapPin, Stethoscope, ChevronLeft, RefreshCw } from 'lucide-react';
import { generateHospitalResponse } from './services/geminiService';
import { KioskHeader } from './components/KioskHeader';
import { ChatBubble } from './components/ChatBubble';

// Types
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

type Language = 'fr' | 'wo' | 'ar';

const LANGUAGES = [
  { code: 'fr', label: 'Français', flag: '🇫🇷', sub: 'Bienvenue' },
  { code: 'wo', label: 'Wolof', flag: '🇸🇳', sub: 'Nanga Def' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦', sub: 'مرحبًا' },
] as const;

export default function App() {
  // View State
  const [view, setView] = useState<'welcome' | 'chat'>('welcome');
  const [selectedLang, setSelectedLang] = useState<Language>('fr');
  
  // Chat State
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis>(window.speechSynthesis);

  // --- Logic ---

  // Start the app with a selected language
  const handleStart = (lang: Language) => {
    setSelectedLang(lang);
    
    // Initialize TTS context on user interaction to prevent browser block
    synthRef.current.cancel(); 
    
    let initialMsg = "";
    switch(lang) {
        case 'wo': initialMsg = "Nanga def. Lo bëgg xam ci hôpital bi?"; break;
        case 'ar': initialMsg = "مرحبًا. كيف يمكنني مساعدتك اليوم؟"; break;
        default: initialMsg = "Bonjour. Je vous écoute pour votre recherche."; break;
    }
    
    setMessages([{ role: 'model', text: initialMsg }]);
    speakText(initialMsg, lang);
    
    setView('chat');
  };

  const returnToHome = () => {
    synthRef.current.cancel();
    if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch(e) {}
    }
    setIsListening(false);
    setView('welcome');
  };

  // Initialize Speech Recognition
  useEffect(() => {
    const { webkitSpeechRecognition, SpeechRecognition } = window as unknown as IWindow;
    const SpeechRecognitionConstructor = SpeechRecognition || webkitSpeechRecognition;

    if (SpeechRecognitionConstructor) {
      const recognition = new SpeechRecognitionConstructor();
      recognition.continuous = false;
      recognition.interimResults = false;
      
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleSend(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech error", event.error);
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  // Update Recognition Language when selection changes
  useEffect(() => {
    if (recognitionRef.current) {
        // Wolof not always supported, fallback to FR
        if (selectedLang === 'wo') recognitionRef.current.lang = 'fr-FR'; 
        else if (selectedLang === 'ar') recognitionRef.current.lang = 'ar-SA';
        else recognitionRef.current.lang = 'fr-FR';
    }
  }, [selectedLang]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const speakText = useCallback((text: string, langCode: Language = selectedLang) => {
    if (!audioEnabled || !synthRef.current) return;
    
    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    // Voice selection logic could be improved here finding specific voices
    if (langCode === 'ar') utterance.lang = 'ar-SA';
    else utterance.lang = 'fr-FR'; // Wolof usually needs FR voice

    utterance.rate = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  }, [audioEnabled, selectedLang]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    setMessages(prev => [...prev, { role: 'user', text: text }]);
    setIsProcessing(true);

    try {
      const responseText = await generateHospitalResponse(text, selectedLang);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
      speakText(responseText);
    } catch (error) {
      const errorMsg = "Erreur technique / Technical error";
      setMessages(prev => [...prev, { role: 'model', text: errorMsg }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      try { recognitionRef.current.stop(); } catch(e) {}
    } else {
      synthRef.current.cancel();
      setIsSpeaking(false);
      try { 
          recognitionRef.current.start(); 
      } catch (e) {
          console.error("Start error", e);
          // Force restart if needed
          try { recognitionRef.current.stop(); setTimeout(() => recognitionRef.current.start(), 100); } catch(e2) {}
      }
    }
  };

  // --- RENDER ---

  // 1. WELCOME SCREEN (Matches Image)
  if (view === 'welcome') {
    return (
      <div className="flex flex-col h-screen bg-slate-50 relative overflow-hidden font-sans">
        
        {/* Top Decoration */}
        <div className="h-2 w-full bg-gradient-to-r from-teal-600 via-green-500 to-teal-600"></div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center z-10">
          
          {/* Logo Animation */}
          <div className="mb-8 relative animate-in zoom-in duration-700">
             <div className="w-32 h-32 bg-white rounded-3xl shadow-xl flex items-center justify-center border border-slate-100 relative overflow-hidden">
                <div className="absolute inset-0 bg-teal-50 opacity-50"></div>
                <Stethoscope size={80} className="text-teal-700 relative z-10" strokeWidth={1.5} />
                <MapPin size={36} className="text-red-500 absolute z-20 top-8 right-8 fill-red-100 animate-bounce" />
             </div>
          </div>

          <h1 className="text-5xl font-bold text-slate-800 mb-2 tracking-tight">Loc-Hops</h1>
          
          <div className="space-y-1 mb-12 text-slate-500">
            <p className="text-xl">Bienvenue</p>
            <p className="text-lg">Nanga Def</p>
            <p className="text-lg font-arabic">مرحبًا</p>
          </div>

          <div className="w-full max-w-md space-y-4">
            <div className="flex items-center justify-center gap-2 text-teal-700 font-medium mb-4">
               <Globe size={20} />
               <span>Choisissez votre langue / Téral sa làkk / اختر لغتك</span>
            </div>

            <div className="grid grid-cols-1 gap-4">
               {LANGUAGES.map((lang) => (
                 <button 
                   key={lang.code}
                   onClick={() => handleStart(lang.code as Language)}
                   className="group relative w-full bg-white hover:bg-teal-50 border-2 border-slate-100 hover:border-teal-200 p-4 rounded-2xl shadow-sm transition-all duration-200 flex items-center justify-between"
                 >
                   <div className="flex items-center gap-4">
                     <span className="text-3xl filter drop-shadow-sm">{lang.flag}</span>
                     <div className="text-left">
                        <span className="block font-bold text-slate-800 group-hover:text-teal-800 text-lg">{lang.label}</span>
                        <span className="block text-xs text-slate-400 group-hover:text-teal-600">{lang.sub}</span>
                     </div>
                   </div>
                   <div className="w-8 h-8 rounded-full bg-slate-50 group-hover:bg-teal-100 flex items-center justify-center text-slate-300 group-hover:text-teal-600">
                      <ChevronLeft className="rotate-180" size={20} />
                   </div>
                 </button>
               ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 text-center text-slate-400 text-sm border-t border-slate-100 bg-white/50">
          <p>Système d'orientation interactif - Hôpital du Sénégal</p>
        </div>
      </div>
    );
  }

  // 2. CHAT SCREEN (Voice Interface)
  return (
    <div className="flex flex-col h-screen bg-slate-50">
      <KioskHeader />
      
      {/* Top Bar: Navigation & Info */}
      <div className="bg-white border-b border-slate-100 px-4 py-2 flex justify-between items-center shadow-sm z-10">
         <button onClick={returnToHome} className="flex items-center gap-2 text-slate-500 hover:text-teal-700 transition-colors px-3 py-1 rounded-lg hover:bg-slate-50">
           <ChevronLeft size={18} />
           <span className="font-medium text-sm">Retour / Accueil</span>
         </button>
         <div className="flex items-center gap-2 text-teal-700 font-bold bg-teal-50 px-3 py-1 rounded-full border border-teal-100">
            <span>{LANGUAGES.find(l => l.code === selectedLang)?.flag}</span>
            <span className="text-sm">{LANGUAGES.find(l => l.code === selectedLang)?.label}</span>
         </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar bg-slate-50">
        {messages.map((msg, idx) => (
          <ChatBubble key={idx} role={msg.role} text={msg.text} />
        ))}
        
        {isProcessing && (
          <div className="flex items-center justify-center p-4">
             <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-sm border border-slate-100">
                <div className="flex gap-1">
                   <span className="w-2 h-2 bg-teal-500 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                   <span className="w-2 h-2 bg-teal-500 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                   <span className="w-2 h-2 bg-teal-500 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
                </div>
                <span className="text-sm text-slate-500 font-medium">Recherche en cours...</span>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Control Area */}
      <div className="bg-white p-8 pb-12 rounded-t-[3rem] shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.05)] border-t border-slate-100 relative">
        <div className="max-w-xl mx-auto flex flex-col items-center gap-6">
          
          {/* Main Interaction Button */}
          <button
            onClick={toggleListening}
            disabled={isProcessing}
            className={`
              relative w-24 h-24 rounded-3xl flex items-center justify-center transition-all duration-500 ease-out
              ${isListening 
                ? 'bg-red-500 text-white shadow-[0_10px_30px_-5px_rgba(239,68,68,0.4)] scale-110 rotate-3' 
                : 'bg-teal-600 text-white shadow-[0_10px_30px_-5px_rgba(13,148,136,0.4)] hover:bg-teal-700 hover:scale-105'}
              ${isProcessing ? 'opacity-50 cursor-not-allowed grayscale' : ''}
            `}
          >
            {isListening ? (
                <div className="relative">
                    <span className="absolute -inset-4 rounded-full border-2 border-white/20 animate-ping"></span>
                    <MicOff size={40} />
                </div>
            ) : (
                <Mic size={40} />
            )}
          </button>

          {/* Instructions Text */}
          <div className="text-center space-y-1">
             <p className={`text-xl font-bold transition-all duration-300 ${isListening ? 'text-red-500 scale-105' : 'text-slate-800'}`}>
               {isListening ? "Je vous écoute..." : "Appuyez pour parler"}
             </p>
             <p className="text-sm text-slate-400 font-medium">
               {selectedLang === 'ar' ? "اضغط للتحدث" : (selectedLang === 'wo' ? "Bësal ngir wax" : "Posez votre question")}
             </p>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-6 mt-4">
             <button 
               onClick={() => setAudioEnabled(!audioEnabled)}
               className={`p-3 rounded-xl transition-colors ${audioEnabled ? 'bg-teal-50 text-teal-700' : 'bg-slate-100 text-slate-400'}`}
             >
                {audioEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
             </button>
             <button 
                onClick={() => handleStart(selectedLang)}
                className="p-3 rounded-xl bg-slate-50 text-slate-500 hover:bg-slate-100 transition-colors"
                title="Relancer la conversation"
             >
                <RefreshCw size={20} />
             </button>
          </div>

        </div>
      </div>
      
      {/* Overlay for missing API Key */}
      {!process.env.API_KEY && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-md text-center">
            <h2 className="text-xl font-bold text-red-600 mb-2">Configuration Requise</h2>
            <p className="text-slate-600">L'IA a besoin d'une API Key pour fonctionner.</p>
          </div>
        </div>
      )}
    </div>
  );
}