import { QrCode } from "lucide-react";

interface QRCodeDisplayProps {
  destination: string;
  language: string;
}

const QRCodeDisplay = ({ destination, language }: QRCodeDisplayProps) => {
  // In a real implementation, this would generate a proper QR code
  // For the prototype, we'll display a placeholder QR code pattern
  
  const generateMobileUrl = () => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/mobile?destination=${destination}&lang=${language}`;
  };

  return (
    <div className="qr-container">
      <div className="relative w-48 h-48 bg-white border-2 border-gray-200 rounded-lg flex items-center justify-center">
        {/* QR Code Pattern Simulation */}
        <svg viewBox="0 0 200 200" className="w-full h-full p-4">
          {/* Corner squares */}
          <rect x="10" y="10" width="50" height="50" fill="black" />
          <rect x="20" y="20" width="30" height="30" fill="white" />
          <rect x="25" y="25" width="20" height="20" fill="black" />
          
          <rect x="140" y="10" width="50" height="50" fill="black" />
          <rect x="150" y="20" width="30" height="30" fill="white" />
          <rect x="155" y="25" width="20" height="20" fill="black" />
          
          <rect x="10" y="140" width="50" height="50" fill="black" />
          <rect x="20" y="150" width="30" height="30" fill="white" />
          <rect x="25" y="155" width="20" height="20" fill="black" />
          
          {/* Data pattern simulation */}
          {Array.from({ length: 15 }, (_, i) =>
            Array.from({ length: 15 }, (_, j) => {
              const shouldFill = (i + j + destination.length) % 3 === 0;
              if ((i < 7 && j < 7) || (i < 7 && j > 12) || (i > 12 && j < 7)) return null;
              return (
                <rect
                  key={`${i}-${j}`}
                  x={10 + i * 12}
                  y={10 + j * 12}
                  width="10"
                  height="10"
                  fill={shouldFill ? "black" : "white"}
                />
              );
            })
          )}
          
          {/* Timing patterns */}
          {Array.from({ length: 19 }, (_, i) => (
            <rect
              key={`h-${i}`}
              x={10 + i * 10}
              y={60}
              width="8"
              height="8"
              fill={i % 2 === 0 ? "black" : "white"}
            />
          ))}
          {Array.from({ length: 19 }, (_, i) => (
            <rect
              key={`v-${i}`}
              x={60}
              y={10 + i * 10}
              width="8"
              height="8"
              fill={i % 2 === 0 ? "black" : "white"}
            />
          ))}
        </svg>
      </div>
      
      <div className="text-center">
        <QrCode className="w-8 h-8 text-primary mx-auto mb-2" />
        <p className="text-lg font-semibold text-primary">QR Code</p>
        <p className="text-sm text-muted-foreground mt-1">
          {generateMobileUrl()}
        </p>
      </div>
    </div>
  );
};

export default QRCodeDisplay;