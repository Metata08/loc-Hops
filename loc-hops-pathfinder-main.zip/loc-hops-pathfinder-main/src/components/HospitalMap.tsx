import { MapPin, Navigation } from "lucide-react";

interface HospitalMapProps {
  destination: string;
  isMobile?: boolean;
}

const HospitalMap = ({ destination, isMobile = false }: HospitalMapProps) => {
  const mapSize = isMobile ? "w-full h-full" : "w-full h-full";

  // Define destinations coordinates based on actual hospital plans
  const destinations = {
    cardiology: { x: 82, y: 25, building: 'Al-Shifa', floor: '2ème' },
    maternity: { x: 25, y: 15, building: 'Hospital', floor: '2ème' },
    radiology: { x: 75, y: 55, building: 'Hospital', floor: 'RDC' },
    emergency: { x: 20, y: 75, building: 'Hospital', floor: 'RDC' },
    laboratory: { x: 60, y: 45, building: 'Al-Shifa', floor: '1er' },
    pharmacy: { x: 45, y: 70, building: 'Hospital', floor: 'RDC' }
  };

  const startPoint = { x: 50, y: 85 }; // Main entrance at the center bottom
  const dest = destinations[destination as keyof typeof destinations] || destinations.cardiology;

  // Create realistic path through hospital corridors
  const createPath = () => {
    // Path routes through main corridors and atrium
    const atriumCenter = { x: 55, y: 40 };
    const corridorEntry = { x: 50, y: 60 };
    
    // Different paths based on destination building
    if (dest.x > 65) { // Al-Shifa building
      return `M ${startPoint.x} ${startPoint.y} L ${corridorEntry.x} ${corridorEntry.y} L ${atriumCenter.x} ${atriumCenter.y} L ${dest.x} ${dest.y}`;
    } else if (dest.x < 50) { // Hospital building
      return `M ${startPoint.x} ${startPoint.y} L ${corridorEntry.x} ${corridorEntry.y} L ${atriumCenter.x - 10} ${atriumCenter.y} L ${dest.x} ${dest.y}`;
    } else { // Central area
      return `M ${startPoint.x} ${startPoint.y} L ${corridorEntry.x} ${corridorEntry.y} L ${dest.x} ${dest.y}`;
    }
  };

  return (
    <div className={`${mapSize} relative bg-gray-50 rounded-2xl overflow-hidden`}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {/* Hospital Complex based on actual plans */}
        
        {/* Main Hospital Building (Left Wing) */}
        <rect x="10" y="10" width="40" height="65" fill="#e3f2fd" stroke="#1976d2" strokeWidth="0.8" rx="3" />
        <text x="30" y="45" textAnchor="middle" className="text-xs font-semibold fill-blue-800" transform="rotate(-90, 30, 45)">
          HOSPITAL
        </text>
        
        {/* Al-Shifa Building (Right Wing) */}
        <rect x="65" y="10" width="30" height="50" fill="#e8f5e8" stroke="#2e7d32" strokeWidth="0.8" rx="3" />
        <text x="80" y="35" textAnchor="middle" className="text-xs font-semibold fill-green-800" transform="rotate(-90, 80, 35)">
          AL-SHIFA
        </text>
        
        {/* Central Atrium/Garden */}
        <ellipse cx="55" cy="40" rx="8" ry="6" fill="#c8e6c9" stroke="#4caf50" strokeWidth="0.5" />
        <circle cx="52" cy="38" r="1" fill="#4caf50" />
        <circle cx="58" cy="42" r="1" fill="#4caf50" />
        <circle cx="55" cy="36" r="0.8" fill="#4caf50" />
        
        {/* Connecting Corridors */}
        <rect x="50" y="35" width="15" height="10" fill="#f5f5f5" stroke="#bdbdbd" strokeWidth="0.3" rx="1" />
        
        {/* Main Entrance Hall */}
        <rect x="35" y="75" width="30" height="15" fill="#fff3e0" stroke="#ff9800" strokeWidth="0.6" rx="2" />
        <text x="50" y="83" textAnchor="middle" className="text-xs font-medium fill-orange-800">
          ACCUEIL
        </text>
        
        {/* Route Path */}
        <path
          d={createPath()}
          className="path-line"
          strokeDasharray="2,1"
          markerEnd="url(#arrowhead)"
        />
        
        {/* Arrow marker definition */}
        <defs>
          <marker
            id="arrowhead"
            markerWidth="3"
            markerHeight="3"
            refX="2.5"
            refY="1.5"
            orient="auto"
          >
            <polygon points="0 0, 3 1.5, 0 3" className="fill-accent" />
          </marker>
        </defs>
        
        {/* Start Point - "VOUS ÊTES ICI" */}
        <circle cx={startPoint.x} cy={startPoint.y} r="2" className="fill-green-500" />
        <text x={startPoint.x} y={startPoint.y + 5} textAnchor="middle" className="text-xs font-semibold fill-green-700" style={{fontSize: '11px'}}>
          VOUS ÊTES ICI
        </text>
        
        {/* Destination Point */}
        <circle cx={dest.x} cy={dest.y} r="2" className="fill-accent animate-pulse" />
        
        {/* Key Landmarks */}
        {/* Main Staircase */}
        <rect x="47" y="50" width="6" height="6" fill="#9e9e9e" stroke="#616161" strokeWidth="0.3" rx="1" />
        <text x="50" y="59" textAnchor="middle" className="text-xs fill-gray-600" style={{fontSize: '10px'}}>
          Escaliers
        </text>
        
        {/* Elevators */}
        <rect x="54" y="50" width="4" height="4" fill="#757575" stroke="#424242" strokeWidth="0.3" rx="0.5" />
        <rect x="54" y="55" width="4" height="4" fill="#757575" stroke="#424242" strokeWidth="0.3" rx="0.5" />
        <text x="56" y="63" textAnchor="middle" className="text-xs fill-gray-600" style={{fontSize: '10px'}}>
          Ascenseurs
        </text>
        
        {/* Reception/Information */}
        <circle cx="50" cy="78" r="2" fill="#2196f3" stroke="#1976d2" strokeWidth="0.3" />
        <text x="50" y="70" textAnchor="middle" className="text-xs fill-blue-700" style={{fontSize: '10px'}}>
          Information
        </text>
      </svg>
      
      {/* Map Legend */}
      <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-3 h-0.5 bg-accent"></div>
          <span className="text-sm">Votre itinéraire</span>
        </div>
        <div className="flex items-center gap-2 mb-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-sm">Départ</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-accent rounded-full animate-pulse"></div>
          <span className="text-sm">Destination</span>
        </div>
      </div>
      
      {/* Destination Info Overlay */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-accent" />
          <div className="text-sm font-semibold">
            {dest.building} - {dest.floor}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalMap;