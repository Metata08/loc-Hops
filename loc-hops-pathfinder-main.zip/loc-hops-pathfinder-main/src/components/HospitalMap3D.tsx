import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text, Box, Sphere, Html } from '@react-three/drei';
import { useRef, useEffect, useState } from 'react';
import { Vector3 } from 'three';
import * as THREE from 'three';
import { MapPin } from 'lucide-react';

interface HospitalMap3DProps {
  destination: string;
  isMobile?: boolean;
}

// Avatar component that walks towards destination following the yellow path
function WalkingAvatar({ targetPosition, startPosition }: { targetPosition: Vector3; startPosition: Vector3 }) {
  const avatarRef = useRef<THREE.Mesh>(null);
  const [currentPosition, setCurrentPosition] = useState(startPosition);
  const [walkProgress, setWalkProgress] = useState(0);

  // Create the same path curve as the yellow line
  const pathCurve = new THREE.CatmullRomCurve3([
    startPosition,
    new Vector3(startPosition.x, startPosition.y, 0),
    new Vector3(targetPosition.x, targetPosition.y, targetPosition.z)
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setWalkProgress((prev) => {
        const newProgress = prev + 0.008; // Slightly slower for better visibility
        if (newProgress >= 1) {
          // Reset to start position and restart the loop
          setTimeout(() => {
            setWalkProgress(0);
            setCurrentPosition(startPosition);
          }, 1000);
          return 1;
        }
        
        // Follow the curve path (2D movement)
        const newPos = pathCurve.getPointAt(newProgress);
        // Keep avatar on ground level (2D movement)
        newPos.y = startPosition.y;
        setCurrentPosition(newPos);
        
        return newProgress;
      });
    }, 60);

    return () => clearInterval(interval);
  }, [targetPosition, startPosition, pathCurve]);

  return (
    <group position={currentPosition} rotation={[0, Math.atan2(targetPosition.x - startPosition.x, targetPosition.z - startPosition.z), 0]}>
      {/* Avatar body */}
      <Box ref={avatarRef} args={[0.3, 0.8, 0.2]} position={[0, 0.4, 0]}>
        <meshStandardMaterial color="#4f46e5" />
      </Box>
      {/* Avatar head */}
      <Sphere args={[0.15]} position={[0, 0.9, 0]}>
        <meshStandardMaterial color="#fbbf24" />
      </Sphere>
      {/* Walking animation - simple bounce */}
      <Box args={[0.1, 0.4, 0.1]} position={[-0.1, 0, 0]} rotation={[Math.sin(walkProgress * 20) * 0.3, 0, 0]}>
        <meshStandardMaterial color="#4f46e5" />
      </Box>
      <Box args={[0.1, 0.4, 0.1]} position={[0.1, 0, 0]} rotation={[Math.sin(walkProgress * 20 + Math.PI) * 0.3, 0, 0]}>
        <meshStandardMaterial color="#4f46e5" />
      </Box>
    </group>
  );
}

function Hospital3DScene({ destination }: { destination: string }) {
  // Define destinations in 3D space
  const destinations = {
    cardiology: { position: new Vector3(4, 1, -2), building: 'Al-Shifa', floor: '2ème', color: '#ef4444', name: 'CARDIOLOGIE' },
    maternity: { position: new Vector3(-4, 1, -4), building: 'Hospital', floor: '2ème', color: '#ec4899', name: 'MATERNITÉ' },
    radiology: { position: new Vector3(3, 0.5, 2), building: 'Hospital', floor: 'RDC', color: '#06b6d4', name: 'RADIOLOGIE' },
    emergency: { position: new Vector3(-4, 0.5, 3), building: 'Hospital', floor: 'RDC', color: '#dc2626', name: 'URGENCES' },
    laboratory: { position: new Vector3(2, 0.5, 0), building: 'Al-Shifa', floor: '1er', color: '#16a34a', name: 'LABORATOIRE' },
    pharmacy: { position: new Vector3(-1, 0.5, 3), building: 'Hospital', floor: 'RDC', color: '#7c3aed', name: 'PHARMACIE' }
  };

  const startPosition = new Vector3(0, 0.5, 5); // Entrance position
  const dest = destinations[destination as keyof typeof destinations] || destinations.cardiology;

  return (
    <>
      {/* Lighting - Medical/Clean ambiance */}
      <ambientLight intensity={0.8} color="#f8fafc" />
      <directionalLight position={[10, 10, 5]} intensity={1.2} color="#ffffff" castShadow />
      <pointLight position={[5, 5, 5]} intensity={0.7} color="#e0f2fe" />
      <pointLight position={[-5, 5, -5]} intensity={0.5} color="#f0f9ff" />

      {/* Ground/Floor - Medical white with subtle grid */}
      <Box args={[15, 0.1, 12]} position={[0, -0.05, 0]}>
        <meshStandardMaterial color="#ffffff" roughness={0.1} metalness={0.05} />
      </Box>
      
      {/* Floor grid pattern */}
      <Box args={[15, 0.02, 0.05]} position={[0, 0, -3]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>
      <Box args={[15, 0.02, 0.05]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>
      <Box args={[15, 0.02, 0.05]} position={[0, 0, 3]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>
      <Box args={[0.05, 0.02, 12]} position={[-5, 0, 0]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>
      <Box args={[0.05, 0.02, 12]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>
      <Box args={[0.05, 0.02, 12]} position={[5, 0, 0]}>
        <meshStandardMaterial color="#e2e8f0" />
      </Box>

      {/* Main Hospital Building (Left Wing) - Medical style */}
      {/* Building walls - Clean medical white */}
      <Box args={[0.2, 3, 8]} position={[-6, 1.5, 0]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[0.2, 3, 8]} position={[0, 1.5, 0]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[6, 3, 0.2]} position={[-3, 1.5, -4]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[6, 3, 0.2]} position={[-3, 1.5, 4]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      
      {/* Internal room divisions - Medical gray */}
      <Box args={[2, 3, 0.1]} position={[-4.5, 1.5, 0]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[2, 3, 0.1]} position={[-1.5, 1.5, 0]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[0.1, 3, 3]} position={[-3, 1.5, 1.5]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[0.1, 3, 3]} position={[-3, 1.5, -1.5]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      
      <Text
        position={[-3, 3.5, 0]}
        fontSize={0.5}
        color="#1e40af"
        anchorX="center"
        anchorY="middle"
        rotation={[-Math.PI / 6, 0, 0]}
      >
        HOSPITAL
      </Text>

      {/* Al-Shifa Building (Right Wing) - Medical style */}
      {/* Building walls - Clean medical white */}
      <Box args={[0.2, 4, 6]} position={[2, 2, -1]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[0.2, 4, 6]} position={[6, 2, -1]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[4, 4, 0.2]} position={[4, 2, -4]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      <Box args={[4, 4, 0.2]} position={[4, 2, 2]}>
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.1} />
      </Box>
      
      {/* Internal room divisions - Medical gray */}
      <Box args={[1.5, 4, 0.1]} position={[3, 2, -1]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[1.5, 4, 0.1]} position={[5, 2, -1]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[0.1, 4, 2]} position={[4, 2, 0]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      <Box args={[0.1, 4, 2]} position={[4, 2, -2]}>
        <meshStandardMaterial color="#f1f5f9" roughness={0.4} metalness={0.05} />
      </Box>
      
      <Text
        position={[4, 4.5, -1]}
        fontSize={0.5}
        color="#059669"
        anchorX="center"
        anchorY="middle"
        rotation={[-Math.PI / 6, 0, 0]}
      >
        AL-SHIFA
      </Text>

      {/* Central Medical Garden/Atrium */}
      <Sphere args={[1.5, 16, 16]} position={[0.5, 0.2, -0.5]}>
        <meshStandardMaterial color="#dcfce7" transparent opacity={0.8} roughness={0.6} />
      </Sphere>

      {/* Connecting Corridors - Medical clean */}
      <Box args={[2, 0.5, 1.5]} position={[0.5, 0.25, 0]}>
        <meshStandardMaterial color="#f8fafc" roughness={0.2} metalness={0.1} />
      </Box>

      {/* Main Entrance - Medical reception style */}
      <Box args={[4, 2, 1]} position={[0, 1, 4.5]}>
        <meshStandardMaterial color="#e0f2fe" roughness={0.3} metalness={0.2} />
      </Box>
      <Text
        position={[0, 2.5, 4.5]}
        fontSize={0.4}
        color="#0369a1"
        anchorX="center"
        anchorY="middle"
      >
        ACCUEIL
      </Text>

      {/* Destination marker */}
      <Sphere args={[0.3]} position={dest.position} >
        <meshStandardMaterial color={dest.color} emissive={dest.color} emissiveIntensity={0.3} />
      </Sphere>
      
      {/* Location icon with bounce animation */}
      <Html position={[dest.position.x, dest.position.y + 0.8, dest.position.z]} center>
        <div className="animate-bounce">
          <MapPin size={32} color={dest.color} fill={dest.color} />
        </div>
      </Html>
      
      {/* Destination label */}
      <Text
        position={[dest.position.x, dest.position.y + 1.5, dest.position.z]}
        fontSize={0.3}
        color={dest.color}
        anchorX="center"
        anchorY="middle"
      >
        {dest.name}
      </Text>

      {/* Start point marker */}
      <Sphere args={[0.2]} position={startPosition}>
        <meshStandardMaterial color="#10b981" emissive="#10b981" emissiveIntensity={0.4} />
      </Sphere>
      
      <Text
        position={[startPosition.x, startPosition.y + 0.8, startPosition.z]}
        fontSize={0.25}
        color="#065f46"
        anchorX="center"
        anchorY="middle"
      >
        VOUS ÊTES ICI
      </Text>

      {/* Walking Avatar */}
      <WalkingAvatar 
        startPosition={startPosition} 
        targetPosition={dest.position}
      />

      {/* Path visualization - simple line */}
      <mesh>
        <tubeGeometry args={[
          new THREE.CatmullRomCurve3([
            startPosition,
            new Vector3(startPosition.x, startPosition.y, 0),
            new Vector3(dest.position.x, dest.position.y, dest.position.z)
          ]),
          20,
          0.05,
          8,
          false
        ]} />
        <meshStandardMaterial color="#f59e0b" emissive="#f59e0b" emissiveIntensity={0.2} />
      </mesh>

      {/* Camera controls */}
      <OrbitControls 
        target={[0, 1, 0]}
        maxPolarAngle={Math.PI / 2.2}
        minDistance={8}
        maxDistance={20}
        enablePan={true}
      />
    </>
  );
}

const HospitalMap3D = ({ destination, isMobile = false }: HospitalMap3DProps) => {
  return (
    <div className={`w-full h-full ${isMobile ? 'min-h-screen' : 'min-h-[600px]'} relative`}>
      <Canvas
        camera={{ position: [8, 6, 8], fov: 60 }}
        shadows
        className="bg-gradient-to-b from-sky-200 to-sky-50"
      >
        <Hospital3DScene destination={destination} />
      </Canvas>
      
      {/* 3D Controls Info */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg text-sm">
        <div className="font-semibold mb-2">Contrôles 3D:</div>
        <div>• Clic + glisser: Rotation</div>
        <div>• Molette: Zoom</div>
        <div>• Clic droit + glisser: Déplacer</div>
      </div>
    </div>
  );
};

export default HospitalMap3D;