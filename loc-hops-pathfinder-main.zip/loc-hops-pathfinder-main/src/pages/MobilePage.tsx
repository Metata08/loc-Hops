import { useState } from "react";
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import HospitalMap3D from "@/components/HospitalMap3D";

const MobilePage = () => {
  const [zoom, setZoom] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const selectedService = localStorage.getItem('selectedService') || 'cardiology';
  const selectedLanguage = localStorage.getItem('selectedLanguage') || 'fr';

  const translations = {
    fr: {
      title: "Plan de l'hôpital",
      zoomIn: "Zoomer",
      zoomOut: "Dézoomer", 
      reset: "Réinitialiser"
    },
    wo: {
      title: "Kat hôpital bi",
      zoomIn: "Gëna gis",
      zoomOut: "Wàññi gis",
      reset: "Delloo"
    },
    ar: {
      title: "خريطة المستشفى",
      zoomIn: "تكبير",
      zoomOut: "تصغير",
      reset: "إعادة تعيين"
    }
  };

  const t = translations[selectedLanguage as keyof typeof translations];

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  const handleReset = () => {
    setZoom(1);
    setPosition({ x: 0, y: 0 });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Mobile Header */}
      <div className="bg-primary text-primary-foreground px-4 py-3 shadow-lg">
        <h1 className="text-2xl font-bold text-center" dir={selectedLanguage === 'ar' ? 'rtl' : 'ltr'}>
          {t.title}
        </h1>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative overflow-hidden">
        <div 
          className="w-full h-full transition-transform duration-300 ease-out"
          style={{
            transform: `scale(${zoom}) translate(${position.x}px, ${position.y}px)`,
            transformOrigin: 'center center'
          }}
        >
          <HospitalMap3D destination={selectedService} isMobile={true} />
        </div>
      </div>

      {/* Controls */}
      <div className="bg-card border-t p-4">
        <div className="flex justify-center gap-4">
          <Button
            variant="outline"
            size="lg"
            onClick={handleZoomOut}
            disabled={zoom <= 0.5}
            className="flex-1 max-w-24"
          >
            <ZoomOut className="w-5 h-5" />
            <span className="sr-only">{t.zoomOut}</span>
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            onClick={handleReset}
            className="flex-1 max-w-32"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            {t.reset}
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            onClick={handleZoomIn}
            disabled={zoom >= 3}
            className="flex-1 max-w-24"
          >
            <ZoomIn className="w-5 h-5" />
            <span className="sr-only">{t.zoomIn}</span>
          </Button>
        </div>
        
        {/* Zoom Indicator */}
        <div className="text-center mt-2">
          <span className="text-sm text-muted-foreground">
            {Math.round(zoom * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
};

export default MobilePage;