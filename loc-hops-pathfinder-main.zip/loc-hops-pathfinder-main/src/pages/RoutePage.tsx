import { useNavigate } from "react-router-dom";
import { ArrowLeft, Printer, MapPin, Clock, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import HospitalMap3D from "@/components/HospitalMap3D";
import QRCodeDisplay from "@/components/QRCodeDisplay";

const RoutePage = () => {
  const navigate = useNavigate();
  const selectedLanguage = localStorage.getItem('selectedLanguage') || 'fr';
  const selectedService = localStorage.getItem('selectedService') || 'cardiology';

  const translations = {
    fr: {
      back: "Retour",
      newSearch: "Nouvelle recherche",
      printMap: "Imprimer le plan",
      scanQR: "Scannez pour obtenir le plan sur votre téléphone",
      walkingTime: "Temps de marche estimé",
      minutes: "minutes",
      building: "Bâtiment",
      floor: "étage",
      services: {
        cardiology: { name: "Service Cardiologie", building: "B", floor: "2ème", time: 4 },
        maternity: { name: "Service Maternité", building: "C", floor: "1er", time: 3 },
        radiology: { name: "Service Radiologie", building: "A", floor: "Rez-de-chaussée", time: 2 },
        emergency: { name: "Service des Urgences", building: "A", floor: "Rez-de-chaussée", time: 1 },
        laboratory: { name: "Laboratoire", building: "B", floor: "1er", time: 3 },
        pharmacy: { name: "Pharmacie", building: "A", floor: "Rez-de-chaussée", time: 2 }
      }
    },
    wo: {
      back: "Dellu",
      newSearch: "Seet wu bees",
      printMap: "Kat bi",
      scanQR: "Scan ngir am kat bi ci téléphone bi",
      walkingTime: "Ñent time bu dëggu",
      minutes: "simili",
      building: "Kër",
      floor: "suuf",
      services: {
        cardiology: { name: "Sarax Cardiologie", building: "B", floor: "2ème", time: 4 },
        maternity: { name: "Sarax Maternité", building: "C", floor: "1er", time: 3 },
        radiology: { name: "Sarax Radiologie", building: "A", floor: "Rez-de-chaussée", time: 2 },
        emergency: { name: "Sarax Urgence", building: "A", floor: "Rez-de-chaussée", time: 1 },
        laboratory: { name: "Laboratoire", building: "B", floor: "1er", time: 3 },
        pharmacy: { name: "Pharmacie", building: "A", floor: "Rez-de-chaussée", time: 2 }
      }
    },
    ar: {
      back: "رجوع",
      newSearch: "بحث جديد", 
      printMap: "طباعة الخريطة",
      scanQR: "امسح للحصول على الخريطة على هاتفك",
      walkingTime: "وقت المشي المقدر",
      minutes: "دقائق",
      building: "مبنى",
      floor: "طابق",
      services: {
        cardiology: { name: "قسم أمراض القلب", building: "B", floor: "2", time: 4 },
        maternity: { name: "قسم الولادة", building: "C", floor: "1", time: 3 },
        radiology: { name: "قسم الأشعة", building: "A", floor: "الأرضي", time: 2 },
        emergency: { name: "قسم الطوارئ", building: "A", floor: "الأرضي", time: 1 },
        laboratory: { name: "المختبر", building: "B", floor: "1", time: 3 },
        pharmacy: { name: "الصيدلية", building: "A", floor: "الأرضي", time: 2 }
      }
    }
  };

  const t = translations[selectedLanguage as keyof typeof translations];
  const serviceInfo = t.services[selectedService as keyof typeof t.services];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="kiosk-container p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Button
          variant="outline"
          size="lg"
          onClick={() => navigate('/destination')}
          className="text-2xl px-8 py-6 touch-friendly"
        >
          <ArrowLeft className="w-8 h-8 mr-4" />
          {t.back}
        </Button>
        
        <Button
          variant="secondary"
          size="lg"
          onClick={() => navigate('/destination')}
          className="text-2xl px-8 py-6 touch-friendly"
        >
          {t.newSearch}
        </Button>
      </div>

      {/* Main Content Layout */}
      <div className="flex gap-8 h-[calc(100vh-200px)]">
        {/* Left Side - Map (70%) */}
        <div className="flex-[7] bg-card rounded-3xl p-6 shadow-lg">
          <HospitalMap3D destination={selectedService} />
        </div>

        {/* Right Side - Information (30%) */}
        <div className="flex-[3] space-y-6" dir={selectedLanguage === 'ar' ? 'rtl' : 'ltr'}>
          {/* Service Information */}
          <div className="bg-card rounded-3xl p-8 shadow-lg">
            <h2 className="text-4xl font-bold text-primary mb-6">
              {serviceInfo.name}
            </h2>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <MapPin className="w-8 h-8 text-accent" />
                <span className="text-2xl">
                  {t.building} {serviceInfo.building}, {serviceInfo.floor} {t.floor}
                </span>
              </div>
              
              <div className="flex items-center gap-4">
                <Clock className="w-8 h-8 text-accent" />
                <span className="text-2xl">
                  {t.walkingTime}: {serviceInfo.time} {t.minutes}
                </span>
              </div>
            </div>
          </div>

          {/* QR Code */}
          <div className="bg-card rounded-3xl p-8 shadow-lg">
            <QRCodeDisplay 
              destination={selectedService}
              language={selectedLanguage}
            />
            <p className="text-xl text-center mt-4 text-muted-foreground">
              {t.scanQR}
            </p>
          </div>

          {/* Print Button */}
          <Button
            variant="outline"
            size="lg"
            onClick={handlePrint}
            className="w-full text-2xl py-8 touch-friendly"
          >
            <Printer className="w-8 h-8 mr-4" />
            {t.printMap}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RoutePage;