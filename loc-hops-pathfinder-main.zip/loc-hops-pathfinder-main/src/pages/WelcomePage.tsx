import { useNavigate } from "react-router-dom";
import { Languages, Heart } from "lucide-react";

const WelcomePage = () => {
  const navigate = useNavigate();

  const selectLanguage = (lang: string) => {
    // Store selected language in localStorage for the session
    localStorage.setItem('selectedLanguage', lang);
    navigate('/destination');
  };

  return (
    <div className="kiosk-container items-center justify-center p-8">
      {/* Header with Logo */}
      <div className="flex items-center justify-center mb-16">
        <div className="flex items-center gap-4">
          <Heart className="w-16 h-16 text-primary" />
          <h1 className="text-7xl font-bold text-primary">Loc-Hops</h1>
        </div>
      </div>

      {/* Welcome Message in Multiple Languages */}
      <div className="text-center mb-16">
        <div className="space-y-4">
          <p className="text-4xl font-semibold text-foreground">Bienvenue</p>
          <p className="text-4xl font-semibold text-muted-foreground">Nanga Def</p>
          <p className="text-4xl font-semibold text-muted-foreground" dir="rtl">مرحبًا</p>
        </div>
      </div>

      {/* Language Selection */}
      <div className="flex flex-col items-center gap-6 mb-8">
        <div className="flex items-center gap-3 mb-6">
          <Languages className="w-12 h-12 text-primary" />
          <h2 className="kiosk-subtitle">Choisissez votre langue / Tëral sa làkk / اختر لغتك</h2>
        </div>
        
        <div className="flex gap-8">
          <button
            onClick={() => selectLanguage('fr')}
            className="language-button bg-primary text-primary-foreground hover:bg-primary/90 touch-friendly"
          >
            <div className="text-5xl mb-2">🇫🇷</div>
            <div>Français</div>
          </button>
          
          <button
            onClick={() => selectLanguage('wo')}
            className="language-button bg-secondary text-secondary-foreground hover:bg-secondary/90 touch-friendly"
          >
            <div className="text-5xl mb-2">🇸🇳</div>
            <div>Wolof</div>
          </button>
          
          <button
            onClick={() => selectLanguage('ar')}
            className="language-button bg-muted text-foreground hover:bg-muted/90 touch-friendly"
            dir="rtl"
          >
            <div className="text-5xl mb-2">🇸🇦</div>
            <div>العربية</div>
          </button>
        </div>
      </div>

      {/* Footer Information */}
      <div className="text-center mt-16">
        <p className="kiosk-text text-muted-foreground">
          Système d'orientation interactif - Hôpital du Sénégal
        </p>
      </div>
    </div>
  );
};

export default WelcomePage;