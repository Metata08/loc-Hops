import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Search, Heart, Baby, Bone, AlertTriangle, TestTube, Pill } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const DestinationPage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const selectedLanguage = localStorage.getItem('selectedLanguage') || 'fr';

  const translations = {
    fr: {
      title: "Où souhaitez-vous aller ?",
      search: "Chercher un service ou un médecin...",
      back: "Retour",
      services: {
        cardiology: "Cardiologie",
        maternity: "Maternité", 
        radiology: "Radiologie",
        emergency: "Urgences",
        laboratory: "Laboratoire",
        pharmacy: "Pharmacie"
      }
    },
    wo: {
      title: "Ana nga bëgg dem ?",
      search: "Seet benn sarax walla doktoore...",
      back: "Dellu",
      services: {
        cardiology: "Cardiologie",
        maternity: "Maternité",
        radiology: "Radiologie", 
        emergency: "Urgence",
        laboratory: "Laboratoire",
        pharmacy: "Pharmacie"
      }
    },
    ar: {
      title: "أين تريد أن تذهب؟",
      search: "ابحث عن خدمة أو طبيب...",
      back: "رجوع",
      services: {
        cardiology: "أمراض القلب",
        maternity: "الولادة",
        radiology: "الأشعة",
        emergency: "الطوارئ", 
        laboratory: "المختبر",
        pharmacy: "الصيدلية"
      }
    }
  };

  const t = translations[selectedLanguage as keyof typeof translations];

  const services = [
    { id: 'cardiology', icon: Heart, color: 'bg-red-100 text-red-600 hover:bg-red-200' },
    { id: 'maternity', icon: Baby, color: 'bg-pink-100 text-pink-600 hover:bg-pink-200' },
    { id: 'radiology', icon: Bone, color: 'bg-blue-100 text-blue-600 hover:bg-blue-200' },
    { id: 'emergency', icon: AlertTriangle, color: 'bg-orange-100 text-orange-600 hover:bg-orange-200' },
    { id: 'laboratory', icon: TestTube, color: 'bg-green-100 text-green-600 hover:bg-green-200' },
    { id: 'pharmacy', icon: Pill, color: 'bg-purple-100 text-purple-600 hover:bg-purple-200' }
  ];

  const selectService = (serviceId: string) => {
    localStorage.setItem('selectedService', serviceId);
    navigate('/route');
  };

  return (
    <div className="kiosk-container p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-12">
        <Button
          variant="outline"
          size="lg"
          onClick={() => navigate('/')}
          className="text-2xl px-8 py-6 touch-friendly"
        >
          <ArrowLeft className="w-8 h-8 mr-4" />
          {t.back}
        </Button>
        
        <div className="flex items-center gap-4">
          <Heart className="w-12 h-12 text-primary" />
          <h1 className="text-5xl font-bold text-primary">Loc-Hops</h1>
        </div>
      </div>

      {/* Title */}
      <div className="text-center mb-16">
        <h2 className="kiosk-title" dir={selectedLanguage === 'ar' ? 'rtl' : 'ltr'}>
          {t.title}
        </h2>
      </div>

      {/* Service Buttons Grid */}
      <div className="grid grid-cols-3 gap-8 mb-16 max-w-6xl mx-auto">
        {services.map((service) => {
          const IconComponent = service.icon;
          return (
            <button
              key={service.id}
              onClick={() => selectService(service.id)}
              className={`service-button ${service.color} touch-friendly`}
            >
              <IconComponent className="w-16 h-16" />
              <span className="text-center">
                {t.services[service.id as keyof typeof t.services]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search Bar */}
      <div className="max-w-2xl mx-auto">
        <div className="relative">
          <Search className="absolute left-6 top-1/2 transform -translate-y-1/2 w-8 h-8 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search}
            className="text-2xl px-20 py-8 rounded-2xl touch-friendly"
            dir={selectedLanguage === 'ar' ? 'rtl' : 'ltr'}
          />
        </div>
      </div>
    </div>
  );
};

export default DestinationPage;