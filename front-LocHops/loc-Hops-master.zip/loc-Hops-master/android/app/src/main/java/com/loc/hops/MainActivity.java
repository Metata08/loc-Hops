package com.loc.hops;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
